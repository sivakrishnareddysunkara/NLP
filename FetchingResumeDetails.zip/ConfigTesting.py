samplePdfPath="C:\\Users\\kousalya.jeevanandam\\Downloads\\Converted"

skillFilePath="C:\\Doc\\ResumeParser\\skills.csv"
